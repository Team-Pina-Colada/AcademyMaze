﻿namespace AcademyMaze
{
    public enum AllyType
    {
        Ivo,
        Joro,
        Niki,
        Doncho,
    }
}
