﻿namespace AcademyMaze
{
    public abstract class Item : WorldObject
    {
        public Item(Coordinates initialCoordinates)
            : base(initialCoordinates)
        {
        }
    }
}
