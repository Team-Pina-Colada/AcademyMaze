﻿namespace AcademyMaze
{
    public enum PlayerType
    {
        Nerd,
        Stubborn,
    }
}
