﻿namespace AcademyMaze
{
    public enum Direction
    {
        Left,
        Right,
        Up,
        Down
    }
}
