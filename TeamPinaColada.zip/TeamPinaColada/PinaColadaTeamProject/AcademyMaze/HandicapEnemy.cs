﻿namespace AcademyMaze
{
    public abstract class HandicapEnemy : Enemy
    {
        public HandicapEnemy(Coordinates initialCoordinates)
            : base(initialCoordinates)
        {
        }
    }
}
